import SwiftUI
import WebKit

private let startAddress = "https://newyork-mafia.com/game/personal/game-hub/"

@MainActor
final class BrowserState: ObservableObject {
    @Published var address = startAddress
    @Published var pageTitle = "NYM Browser"
    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published var isLoading = false
    @Published var loadProgress = 0.0

    let webView: WKWebView
    private var progressObservation: NSKeyValueObservation?

    init() {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        webView = WKWebView(frame: .zero, configuration: configuration)
        webView.allowsBackForwardNavigationGestures = true
        progressObservation = webView.observe(\.estimatedProgress, options: [.new]) { [weak self] view, _ in
            Task { @MainActor in self?.loadProgress = view.estimatedProgress }
        }
    }

    func load(_ input: String) {
        let trimmed = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        let candidate: String
        if let parsed = URL(string: trimmed), parsed.scheme != nil {
            candidate = trimmed
        } else if trimmed.contains(".") && !trimmed.contains(" ") {
            candidate = "https://\(trimmed)"
        } else {
            candidate = "https://duckduckgo.com/?q=\(trimmed.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? trimmed)"
        }
        guard let url = URL(string: candidate) else { return }
        address = url.absoluteString
        webView.load(URLRequest(url: url))
    }

    func goHome() {
        guard let url = URL(string: startAddress) else { return }
        address = startAddress
        webView.load(URLRequest(url: url))
    }
    func goBack() { if webView.canGoBack { webView.goBack() } }
    func goForward() { if webView.canGoForward { webView.goForward() } }
    func reload() { webView.reload() }

    func syncFromWebView() {
        address = webView.url?.absoluteString ?? address
        pageTitle = webView.title?.isEmpty == false ? (webView.title ?? "NYM Browser") : "NYM Browser"
        canGoBack = webView.canGoBack
        canGoForward = webView.canGoForward
        isLoading = webView.isLoading
    }
}

struct BrowserView: View {
    @StateObject private var state = BrowserState()
    @FocusState private var editingAddress: Bool

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Button(action: state.goBack) { Image(systemName: "chevron.left") }
                    .disabled(!state.canGoBack)
                Button(action: state.goForward) { Image(systemName: "chevron.right") }
                    .disabled(!state.canGoForward)
                Button(action: state.goHome) { Image(systemName: "house") }
                TextField("Search or enter address", text: $state.address, onCommit: {
                    state.load(state.address)
                    editingAddress = false
                })
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .keyboardType(.URL)
                .textFieldStyle(.roundedBorder)
                .focused($editingAddress)
                Button(action: state.reload) { Image(systemName: state.isLoading ? "xmark" : "arrow.clockwise") }
            }
            .buttonStyle(.plain)
            .font(.system(size: 17, weight: .semibold))
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(Color(.secondarySystemBackground))

            if state.isLoading {
                ProgressView(value: state.loadProgress)
                    .tint(.green)
                    .padding(.horizontal, 8)
            }

            WebViewContainer(state: state)
                .ignoresSafeArea(edges: .bottom)
        }
        .background(Color(.systemBackground))
        .safeAreaInset(edge: .bottom) {
            HStack {
                Text(state.pageTitle).lineLimit(1)
                Spacer()
                Text("Private beta").foregroundStyle(.secondary)
            }
            .font(.caption)
            .padding(.horizontal, 14)
            .padding(.vertical, 8)
            .background(Color(.secondarySystemBackground))
        }
        .onAppear { if state.webView.url == nil { state.goHome() } }
    }
}

private struct WebViewContainer: UIViewRepresentable {
    @ObservedObject var state: BrowserState

    func makeCoordinator() -> Coordinator { Coordinator(state: state) }
    func makeUIView(context: Context) -> WKWebView {
        state.webView.navigationDelegate = context.coordinator
        return state.webView
    }
    func updateUIView(_ webView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKNavigationDelegate {
        private let state: BrowserState
        init(state: BrowserState) { self.state = state }
        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) { state.syncFromWebView() }
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) { state.syncFromWebView() }
        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { state.syncFromWebView() }
        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { state.syncFromWebView() }
    }
}
