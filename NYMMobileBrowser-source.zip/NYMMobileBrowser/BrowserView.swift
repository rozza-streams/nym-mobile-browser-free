import SwiftUI
import WebKit

private let startAddress = "https://newyork-mafia.com/game/personal/game-hub/"

struct ObservedStatus: Identifiable, Equatable {
    let group: String
    let label: String
    let value: String
    var id: String { "\(group)-\(label)" }
}

@MainActor
final class BrowserState: ObservableObject {
    @Published var address = startAddress
    @Published var pageTitle = "NYM Browser"
    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published var isLoading = false
    @Published var loadProgress = 0.0
    @Published var observedStatuses: [ObservedStatus] = []
    @Published var verificationNotice: String?
    @Published var observationPage = ""
    @Published var observedAt: Date?

    let webView: WKWebView
    private let scriptBridge = ScriptMessageBridge()
    private var progressObservation: NSKeyValueObservation?

    init() {
        let contentController = WKUserContentController()
        contentController.addUserScript(WKUserScript(
            source: Self.readOnlyObserverScript,
            injectionTime: .atDocumentEnd,
            forMainFrameOnly: true
        ))

        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        configuration.userContentController = contentController
        webView = WKWebView(frame: .zero, configuration: configuration)
        webView.allowsBackForwardNavigationGestures = true
        scriptBridge.state = self
        contentController.add(scriptBridge, name: "nymReadOnlyStatus")
        progressObservation = webView.observe(\.estimatedProgress, options: [.new]) { [weak self] view, _ in
            Task { @MainActor in self?.loadProgress = view.estimatedProgress }
        }
    }

    func load(_ input: String) {
        let trimmed = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        let candidate: String
        if let parsed = URL(string: trimmed), parsed.scheme != nil {
            candidate = trimmed
        } else if trimmed.contains(".") && !trimmed.contains(" ") {
            candidate = "https://\(trimmed)"
        } else {
            candidate = "https://duckduckgo.com/?q=\(trimmed.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? trimmed)"
        }
        guard let url = URL(string: candidate) else { return }
        address = url.absoluteString
        webView.load(URLRequest(url: url))
    }

    func goHome() {
        guard let url = URL(string: startAddress) else { return }
        address = startAddress
        webView.load(URLRequest(url: url))
    }
    func goBack() { if webView.canGoBack { webView.goBack() } }
    func goForward() { if webView.canGoForward { webView.goForward() } }
    func reload() { webView.reload() }

    func syncFromWebView() {
        address = webView.url?.absoluteString ?? address
        pageTitle = webView.title?.isEmpty == false ? (webView.title ?? "NYM Browser") : "NYM Browser"
        canGoBack = webView.canGoBack
        canGoForward = webView.canGoForward
        isLoading = webView.isLoading
    }

    fileprivate func receiveReadOnlyObservation(_ body: Any) {
        guard let payload = body as? [String: Any],
              let host = webView.url?.host?.lowercased(),
              host == "newyork-mafia.com" || host.hasSuffix(".newyork-mafia.com") else { return }

        let rows = (payload["rows"] as? [[String: String]] ?? []).compactMap { row -> ObservedStatus? in
            guard let group = row["group"], let label = row["label"], let value = row["value"], !value.isEmpty else { return nil }
            return ObservedStatus(group: group, label: label, value: value)
        }
        observedStatuses = rows
        verificationNotice = payload["verification"] as? String
        observationPage = payload["path"] as? String ?? ""
        observedAt = Date()
    }

    private static let readOnlyObserverScript = #"""
    (() => {
      if (location.hostname !== 'newyork-mafia.com' && !location.hostname.endsWith('.newyork-mafia.com')) return;
      if (window.__nymMobileReadOnlyObserver) return;
      window.__nymMobileReadOnlyObserver = true;
      const resourceNames = ['Money','Bullets','Kevlar','Health','Rank','Location','Points'];
      const activityNames = ['Travel','Crime','Extortion','Escape','Theft','MMA','Smuggling','Recruit','Jail'];
      const allNames = [...resourceNames, ...activityNames];
      const normalize = value => String(value || '').replace(/\s+/g, ' ').trim();
      const visible = element => {
        const style = getComputedStyle(element);
        if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0) return false;
        const rect = element.getBoundingClientRect();
        return rect.width > 0 && rect.height > 0;
      };
      const readRows = () => {
        const found = new Map();
        const nodes = [...document.querySelectorAll('div,span,strong,small,li,td,th,button,a')]
          .filter(element => visible(element) && element.children.length < 6)
          .map(element => normalize(element.innerText || element.textContent))
          .filter(text => text && text.length < 90);
        for (const name of allNames) {
          const candidates = nodes.filter(text => new RegExp('^' + name + '(?:\\s|$)', 'i').test(text));
          if (!candidates.length) continue;
          candidates.sort((a, b) => a.length - b.length);
          const value = candidates[0].replace(new RegExp('^' + name + '\\s*', 'i'), '').trim();
          if (value) found.set(name, { group: resourceNames.includes(name) ? 'Resources' : 'Timers & activity', label: name, value });
        }
        return [...found.values()];
      };
      const publish = () => {
        const body = normalize(document.body?.innerText || '');
        const gate = /verification required|complete the verification to continue|quick verification/i.test(body);
        const rows = readRows();
        try {
          window.webkit?.messageHandlers?.nymReadOnlyStatus?.postMessage({
            rows,
            verification: gate ? 'NYM is asking for verification. Complete it yourself in the game page.' : '',
            path: location.pathname
          });
        } catch (_) {}
      };
      publish();
      setInterval(publish, 2000);
      const observer = new MutationObserver(() => publish());
      observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
    })();
    """#
}

private final class ScriptMessageBridge: NSObject, WKScriptMessageHandler {
    weak var state: BrowserState?

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "nymReadOnlyStatus" else { return }
        let target = state
        let body = message.body
        Task { @MainActor [weak target] in target?.receiveReadOnlyObservation(body) }
    }
}

struct BrowserView: View {
    @StateObject private var state = BrowserState()
    @State private var showingStatus = false
    @FocusState private var editingAddress: Bool

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Button(action: state.goBack) { Image(systemName: "chevron.left") }
                    .disabled(!state.canGoBack)
                Button(action: state.goForward) { Image(systemName: "chevron.right") }
                    .disabled(!state.canGoForward)
                Button(action: state.goHome) { Image(systemName: "house") }
                TextField("Search or enter address", text: $state.address, onCommit: {
                    state.load(state.address)
                    editingAddress = false
                })
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .keyboardType(.URL)
                .textFieldStyle(.roundedBorder)
                .focused($editingAddress)
                Button(action: state.reload) { Image(systemName: state.isLoading ? "xmark" : "arrow.clockwise") }
            }
            .buttonStyle(.plain)
            .font(.system(size: 17, weight: .semibold))
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(Color(.secondarySystemBackground))

            if state.isLoading {
                ProgressView(value: state.loadProgress)
                    .tint(.green)
                    .padding(.horizontal, 8)
            }

            WebViewContainer(state: state)
                .ignoresSafeArea(edges: .bottom)
        }
        .background(Color(.systemBackground))
        .safeAreaInset(edge: .bottom) {
            HStack(spacing: 8) {
                Text(state.pageTitle).lineLimit(1)
                Spacer(minLength: 6)
                Button {
                    showingStatus = true
                } label: {
                    Label("Status", systemImage: "chart.bar.xaxis")
                }
                .labelStyle(.titleAndIcon)
                .font(.caption.weight(.semibold))
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 8)
            .background(Color(.secondarySystemBackground))
        }
        .sheet(isPresented: $showingStatus) {
            ReadOnlyStatusView(state: state)
        }
        .onAppear { if state.webView.url == nil { state.goHome() } }
    }
}

private struct ReadOnlyStatusView: View {
    @ObservedObject var state: BrowserState

    private var resources: [ObservedStatus] { state.observedStatuses.filter { $0.group == "Resources" } }
    private var activities: [ObservedStatus] { state.observedStatuses.filter { $0.group == "Timers & activity" } }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    if let notice = state.verificationNotice, !notice.isEmpty {
                        Label(notice, systemImage: "exclamationmark.triangle.fill")
                            .foregroundStyle(.orange)
                    } else {
                        Label("Read-only page observer", systemImage: "eye")
                            .foregroundStyle(.green)
                    }
                    Text(state.observationPage.isEmpty ? "Open a NYM game page to read its visible status." : state.observationPage)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                    if let observedAt = state.observedAt {
                        Text("Updated \(observedAt.formatted(date: .omitted, time: .shortened))")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                }

                if !resources.isEmpty {
                    Section("Resources") {
                        ForEach(resources) { row in statusRow(row) }
                    }
                }

                if !activities.isEmpty {
                    Section("Timers & activity") {
                        ForEach(activities) { row in statusRow(row) }
                    }
                }

                if resources.isEmpty && activities.isEmpty {
                    Section("What this shows") {
                        Text("Visible NYM resources and activity timers appear here when the page provides them. This screen only reads the page; it does not submit actions, change settings, or handle verification.")
                            .font(.callout)
                    }
                }
            }
            .navigationTitle("NYM status")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }

    @Environment(\.dismiss) private var dismiss

    @ViewBuilder
    private func statusRow(_ row: ObservedStatus) -> some View {
        HStack {
            Text(row.label)
            Spacer()
            Text(row.value)
                .fontWeight(.semibold)
                .multilineTextAlignment(.trailing)
        }
    }
}

private struct WebViewContainer: UIViewRepresentable {
    @ObservedObject var state: BrowserState

    func makeCoordinator() -> Coordinator { Coordinator(state: state) }
    func makeUIView(context: Context) -> WKWebView {
        state.webView.navigationDelegate = context.coordinator
        return state.webView
    }
    func updateUIView(_ webView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKNavigationDelegate {
        private let state: BrowserState
        init(state: BrowserState) { self.state = state }
        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) { state.syncFromWebView() }
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) { state.syncFromWebView() }
        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { state.syncFromWebView() }
        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { state.syncFromWebView() }
    }
}
